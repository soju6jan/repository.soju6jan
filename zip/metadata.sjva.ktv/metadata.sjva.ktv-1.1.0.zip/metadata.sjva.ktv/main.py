#!/usr/bin/env python
# -*- coding: UTF-8 -*-
if __name__ == '__main__':
    from lib.ktv import MetadataKtv
    MetadataKtv().run()
