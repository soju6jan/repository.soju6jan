#!/usr/bin/env python
# -*- coding: UTF-8 -*-
if __name__ == '__main__':
    from lib.movie import MetadataMovie
    MetadataMovie('jav_censored').run()
